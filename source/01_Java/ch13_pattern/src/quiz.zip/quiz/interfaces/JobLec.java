package quiz.interfaces;

public class JobLec implements JobImpl {

	@Override
	public void job() {
		System.out.println("���Ǹ� �մϴ�");
		System.out.println("------");
	}

}
