package quiz.interfaces;

public interface GetImpl {
	public void get();
}
